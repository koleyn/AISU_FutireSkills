from tkinter import *
import time
import pygame
pygame.init()



window = pygame.display.set_mode((1088, 650))
track = pygame.image.load('track_test4.png')
car = pygame.image.load('red_car.png')
car = pygame.transform.scale(car,(15, 30))
#светофор

brick1 = pygame.image.load('brick.png')
finish = pygame.image.load('finish.png')
brick1 = pygame.transform.scale(brick1, (25,25))
brick2 = pygame.transform.scale(brick1, (25,25))
brick3 = pygame.transform.scale(brick1, (25,25))
brick4 = pygame.transform.scale(brick1, (25,25))
brick5 = pygame.transform.scale(brick1, (25,25))
brick6 = pygame.transform.scale(brick1, (25,25))
brick7 = pygame.transform.scale(brick1, (25,25))
brick8 = pygame.transform.scale(brick1, (25,25))
brick9 = pygame.transform.scale(brick1, (25,25))
finish = pygame.transform.scale(finish, (34,17))
car_x = 50
car_y = 440
brick1_x = 360
brick1_y = 155
brick2_x = 388
brick2_y = 210
brick3_x = 301
brick3_y = 320
brick4_x = 178
brick4_y = 230
brick5_x = 151
brick5_y = 230
brick6_x = 57
brick6_y = 340
brick7_x = 30
brick7_y = 340
brick8_x = 230
brick8_y = 390
brick9_x = 355
brick9_y = 280
finish_x = 325
finish_y = -3
drive = True
clock = pygame.time.Clock()
focal_dis = 40
cam_x_offset = 0
cam_y_offset = 0
direction = 'up'


while drive:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            drive = False
    clock.tick(40)
    cam_x = car_x + cam_x_offset +13
    cam_y = car_y + cam_y_offset +13
    up_px = window.get_at((cam_x,cam_y-focal_dis))[0]
    down_px = window.get_at((cam_x, cam_y + focal_dis))[0]
    right_px = window.get_at((cam_x + focal_dis, cam_y))[0]
    left_px = window.get_at((cam_x - focal_dis, cam_y))[0]
    print(up_px, right_px, down_px, left_px)
    
    if direction == 'up' and up_px != 0 and right_px == 0:
        direction = 'right'
        cam_x_offset = 30
        car = pygame.transform.rotate(car, -90)
        
    elif direction == 'right' and  right_px !=0 and up_px == 0:
        direction = 'up'
        car_x = car_x + 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car,90)

    elif direction == "right" and right_px != 0 and down_px == 0:
        direction = 'down'
        car_y = car_y - 30
        cam_x_offset = 0
        cam_y_offset = 30
        car = pygame.transform.rotate(car, -90)

    elif direction == 'down' and down_px != 0 and right_px == 0:
        direction = 'right'
        cam_x_offset = 30
        car = pygame.transform.rotate(car, 90)
  

    elif direction == 'down' and  down_px !=0 and left_px == 0:
        direction = 'left'
        car_x = car_x + 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car, -90)

    elif direction == 'up' and  up_px !=0 and left_px == 0:
        direction = 'left'
        car_x = car_x - 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car, -90)

    elif direction == 'left' and  left_px !=0 and up_px == 0:
        direction = 'up'
        car_x = car_x + 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car,-90)


        
    if direction == 'up' and up_px == 0:
        car_y = car_y - 2
    elif direction == 'right' and  right_px == 0:
        car_x = car_x + 2
    elif direction == 'down' and down_px == 0:
        car_y = car_y + 2
    elif direction == 'left' and  left_px == 0:
        car_x = car_x - 2
        
    window.blit(track, (0,0))
    window.blit(car, (car_x, car_y))
    window.blit(brick1, (brick1_x, brick1_y))
    window.blit(brick2, (brick2_x, brick2_y))
    window.blit(brick3, (brick3_x, brick3_y))
    window.blit(brick4, (brick4_x, brick4_y))
    window.blit(brick5, (brick5_x, brick5_y))
    window.blit(brick6, (brick6_x, brick6_y))
    window.blit(brick7, (brick7_x, brick7_y))
    window.blit(brick8, (brick8_x, brick8_y))
    window.blit(brick9, (brick9_x, brick9_y))
    window.blit(finish, (finish_x, finish_y))
    pygame.draw.circle(window,(0, 255, 0), (cam_x, cam_y), 5, 5)
    pygame.display.update()

