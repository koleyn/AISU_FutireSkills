import pygame

pygame.init()

window = pygame.display.set_mode((1088, 650))
track = pygame.image.load('road.png')
car = pygame.image.load('Cbottom.png')
finish = pygame.image.load('finish.png')
car = pygame.transform.scale(car, (20, 20))
finish = pygame.transform.scale(finish, (34,17))
car_x = 254
car_y = 45
finish_x = 737
finish_y = 559
drive = True
clock = pygame.time.Clock()
focal_dis = 0
cam_x_offset = 0
cam_y_offset = 0
direction = 'up'
while drive:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            drive = False
    clock.tick(40)
    cam_x = car_x + cam_x_offset + 15
    cam_y = car_y + cam_y_offset + 15
    up_px = window.get_at((cam_x, cam_y - focal_dis))[0]
    down_px = window.get_at((cam_x, cam_y + focal_dis))[0]
    right_px = window.get_at((cam_x + focal_dis, cam_y))[0]
    left_px = window.get_at((cam_x - focal_dis, cam_y))[0]
    print(up_px, right_px, down_px, left_px)

    if direction == 'up' and up_px != 0 and right_px == 0:
        direction = 'right'
        cam_x_offset = 30
        car = pygame.transform.rotate(car, -90)

    elif direction == 'right' and right_px != 0 and up_px == 0:
        direction = 'up'
        car_x = car_x + 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car, 90)

    elif direction == "right" and right_px != 0 and down_px == 0:
        direction = 'down'
        car_y = car_y - 30
        cam_x_offset = 0
        cam_y_offset = 30
        car = pygame.transform.rotate(car, -90)

    elif direction == 'down' and down_px != 0 and right_px == 0:
        direction = 'right'
        cam_x_offset = 30
        car = pygame.transform.rotate(car, 90)


    elif direction == 'down' and down_px != 0 and left_px == 0:
        direction = 'left'
        car_x = car_x + 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car, -90)

    elif direction == 'up' and up_px != 0 and left_px == 0:
        direction = 'left'
        car_x = car_x - 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car, -90)

    elif direction == 'left' and left_px != 0 and up_px == 0:
        direction = 'up'
        car_x = car_x + 30
        cam_x_offset = 0
        car = pygame.transform.rotate(car, -90)

    if direction == 'up' and up_px == 0:
        car_y = car_y - 1
    elif direction == 'right' and right_px == 0:
        car_x = car_x + 1
    elif direction == 'down' and down_px == 0:
        car_y = car_y + 1
    elif direction == 'left' and left_px == 0:
        car_x = car_x - 1
    window.blit(track, (0, 0))
    window.blit(car, (car_x, car_y))
    pygame.draw.circle(window, (0, 0, 0), (cam_x, cam_y), 0, 0)
    window.blit(finish, (finish_x, finish_y))
    pygame.display.update()
