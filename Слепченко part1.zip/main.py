#-*-coding: utf-8-*-
import pygame, sys, time
from pygame.locals import *

from tkinter import *
from tkinter import ttk

root = Tk()
root.geometry("200x200")

# стандартная кнопка
btn = ttk.Button(text="Клик")

btn.pack()

root.mainloop()
# Блоки-ограничители рисуются как отдельные поверхности
# Между ними курсором перемещаем мячик

FPS = 30  # кадров в сек
# Размеры окна игры
width = 629
height = 649
# Заголовок окна игры
title = "test"
# Сообщение в консоль игры
info = "Нет столкновений \n"
# Переменная - индикатор движения
direction = False
# Шаг движения
myStep = 2
pygame.mixer.init()
pygame.font.init()
pygame.init()

fpsClock = pygame.time.Clock()
mainSurface = pygame.display.set_mode((width, height), 0, 32)
pygame.display.set_caption(title)
pygame.mixer.music.load('Resources/370b925a30aca01.mp3')
background = pygame.image.load('Resources/road_TD2.png')  # Фон
sprite = pygame.image.load('Resources/GCicon.ico')  # Подвижная картинка

# Начальные координаты подвижной картинки
# Важно, чтобы в начале работы она не перекрывала ни один блок
spriteX = 57
spriteY = 600

# Неподвижные блоки - все сохраняем в одном списке
# Структура списка blocks:
# каждый элемент - пара значений: (поверхность, область её размещения)
# blocks[0] - первый элемент списка, blocks[0][0] - surface первого элемента,blocks[0][1]  - Rect первого элемента
blocks = []
block1 = pygame.Surface((20, 150))
#block1.set_alpha(80)
block1.fill((240,240,240))
block1Rect = pygame.Rect(70, 0, block1.get_width(), block1.get_height())
blocks.append((block1, block1Rect))

block2 = pygame.Surface((255, 70))
block2.fill((240,240,240))
block2Rect = pygame.Rect(160, 0, block2.get_width(), block2.get_height())
blocks.append((block2, block2Rect))

block3 = pygame.Surface((25, 700))
block3.fill((240,240,240))
block3Rect = pygame.Rect(0, 0, block3.get_width(), block3.get_height())
blocks.append((block3, block3Rect))
posit = pygame.font.SysFont('Comic Sans MS', 30)

block4 = pygame.Surface((625, 120))
block4.fill((240,240,240))
block4Rect = pygame.Rect(95, 585, block4.get_width(), block4.get_height())
blocks.append((block4, block4Rect))
posit = pygame.font.SysFont('Comic Sans MS', 30)

block5 = pygame.Surface((222, 60))
block5.fill((240,240,240))
block5Rect = pygame.Rect(0, 137, block5.get_width(), block5.get_height())
blocks.append((block5, block5Rect))
posit = pygame.font.SysFont('Comic Sans MS', 30)

block6 = pygame.Surface((125, 60))
block6.fill((240,240,240))
block6Rect = pygame.Rect(290, 137, block6.get_width(), block6.get_height())
blocks.append((block6, block6Rect))
posit = pygame.font.SysFont('Comic Sans MS', 30)

block7 = pygame.Surface((125, 90))
block7.fill((240,240,240))
block7Rect = pygame.Rect(290, 265, block7.get_width(), block7.get_height())
blocks.append((block7, block7Rect))
posit = pygame.font.SysFont('Comic Sans MS', 30)

block8 = pygame.Surface((125, 90))
block8.fill((240,240,240))
block8Rect = pygame.Rect(290, 425, block8.get_width(), block8.get_height())
blocks.append((block8, block8Rect))
posit = pygame.font.SysFont('Comic Sans MS', 30)

block9 = pygame.Surface((125, 90))
block9.fill((240,240,240))
block9Rect = pygame.Rect(95, 425, block9.get_width(), block9.get_height())
blocks.append((block9, block9Rect))
posit = pygame.font.SysFont('Comic Sans MS', 30)

block10 = pygame.Surface((125, 90))
block10.fill((240,240,240))
block10Rect = pygame.Rect(95, 265, block10.get_width(), block10.get_height())
blocks.append((block10, block10Rect))
posit = pygame.font.SysFont('Comic Sans MS', 30)
# закончили с описанием 3-х блоков

# *********>
def newPosition(direction, spriteX, spriteY):
    # Функция пересчитывает координаты новой позиции подвижного объекта
    # Проверяем столкновений со всеми блоками-границаи
    global myStep
    if direction:
        if direction == K_UP:
            spriteY -= myStep
        elif direction == K_DOWN:
            spriteY += myStep
        elif direction == K_LEFT:
            spriteX -= myStep
        elif direction == K_RIGHT:
            spriteX += myStep
    return spriteX, spriteY


# *********>


# *********>
def collisionDetected():
    global blocks
    global spriteRectNew
    colFlag = False
    # Проверка столкновений со всеми блоками в массиве блоков
    for block in blocks:
        if spriteRectNew.colliderect(block[1]):
            collisionDir = direction
            colFlag = True

    return colFlag



# *********>

# Цикл игры
while True:

    fpsClock.tick(FPS)  # Частота обновления экрана
    # Обрабатываем очередь событий - начало
    for event in pygame.event.get():
        # В цикле берём из очереди очередное событие, запоминаем в переменной event
        # Проверяем тип события и выполняем соответствующие лействия
        if event.type == QUIT:
            # Тип проверяемого события НАЖАТ Х В ОКНЕ ИГРЫ
            pygame.quit()
            sys.exit()
        if event.type == KEYDOWN and event.key == K_ESCAPE:
            # ESC key pressed
            pygame.quit()
            sys.exit()

        # Следующая строка получает управление только тогда, когда не отработали предыдущие проверки кода события
        # то есть произошло событие, отличное от перечисленных выше
        if event.type == KEYDOWN:
            direction = event.key
        if event.type == KEYUP:
            direction = False  # Кнопка отпущена
    # Обрабатываем очередь событий - конец

    # Текущее место расположения подвижной картинки
    spriteRect = pygame.Rect(spriteX,spriteY,sprite.get_width(), sprite.get_height())

    # Сохраняем старые координаты
    oldPos = (spriteX, spriteY)

    # Вычмсляем новые координаты, анализируя нажатые кнопки
    spriteX, spriteY = newPosition(direction, spriteX, spriteY)

    # Вычисляем новое место расположения картинки
    spriteRectNew = pygame.Rect(spriteX, spriteY, sprite.get_width(), sprite.get_height())

    # Проверяем, не пересекает ли новое место блоки. Если пересекает, то вовращпни картинке старые координаты
    if collisionDetected():
        (spriteX, spriteY) = oldPos
        # Play OOPS!
        pygame.mixer.music.play()

    # Рисуем всё на экране
    #    Фон
    mainSurface.blit(background, (0, 0))

    #    Блоки
    for block in blocks:
        mainSurface.blit(block[0], (block[1].x, block[1].y))
    #    Картинку
    mainSurface.blit(sprite, (spriteRect.x, spriteRect.y))
    #    Обновляем экран
    pygame.display.update()